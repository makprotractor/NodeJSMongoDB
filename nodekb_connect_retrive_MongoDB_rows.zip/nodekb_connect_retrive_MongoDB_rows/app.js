const express = require('express');
const path = require('path');
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/nodekb');
let db = mongoose.connection;

//check connection
db.once('open',function(){
  console.log("db Connected to Mongo DB......");
});

// check for DB server
db.on('error', function(err){
  console.log(err);
});

//init App
const app = express();

//Bring in models
let Article = require('./models/article');

//load view engine
app.set('views',path.join(__dirname,'views'));
app.set('view engine', 'pug');


// Home route
app.get('/', function(req,res){
  Article.find({}, function(err, articles){
  if(err){

  }
  else {


    res.render('index',{
      title:'articles',
      articles: articles
    });
  }
  });
  });
  // let articles =[
  //   {  id:1,
  //     title:'Article One',
  //     author:'Arun Mannepula',
  //     body:'This is article one'
  //   },
  //   {  id:2,
  //     title:'Article Two',
  //     author:'Arun Kumar',
  //     body:'This is article Two'
  //   },
  //   {  id:3,
  //     title:'Article Three',
  //     author:'M A Kumar',
  //     body:'This is article Three'
  //   }
  //
  // ];




//Add route
app.get('/articles/add1', function(req,res){
  res.render('add_article',{
    title:'Add articles'
  });
});
// start server
app.listen(3000, function(){
  console.log('server started on 3000 ' );
});
